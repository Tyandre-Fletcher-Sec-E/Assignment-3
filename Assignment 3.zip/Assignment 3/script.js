let isAuthenticated = true;

 function checkAnswers() {
    if(isAuthenticated === true){
        const form = document.getElementById("quiz-form");
    const answers = {
        q1: "paris",
        q2: "0",
        q3: "100",
        q4: "venus"
    };
    let score = 0;

    for (const question in answers) {
        const selectedAnswer = form.querySelector(`input[name="${question}"]:checked`);
        if (selectedAnswer) {
            if (selectedAnswer.value === answers[question]) {
                score++;
            }
        }
    }

    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = `Your score: ${score} out of ${Object.keys(answers).length}`;

    }
}